class AppConstants {
  // TODO: Replace with your actual Supabase URL and Anon Key
  static const String supabaseUrl = 'https://vmwkqwoclyslfsodqdep.supabase.co';
  static const String supabaseAnonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZtd2txd29jbHlzbGZzb2RxZGVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjYxMTMxNjQsImV4cCI6MjA4MTY4OTE2NH0.FoXs5VQxeAnQNnsIM76IvrO9GFqVRhrV2kMiISrVzhg';
}
