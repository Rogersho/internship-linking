// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$myInternshipsHash() => r'b88c2355d849223735e19beafba689ed96056de3';

/// See also [myInternships].
@ProviderFor(myInternships)
final myInternshipsProvider =
    AutoDisposeFutureProvider<List<Internship>>.internal(
  myInternships,
  name: r'myInternshipsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$myInternshipsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef MyInternshipsRef = AutoDisposeFutureProviderRef<List<Internship>>;
String _$myApplicationsHash() => r'44bc975202a4f989720c4355cc50591a8fffb809';

/// See also [myApplications].
@ProviderFor(myApplications)
final myApplicationsProvider =
    AutoDisposeFutureProvider<List<Application>>.internal(
  myApplications,
  name: r'myApplicationsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$myApplicationsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef MyApplicationsRef = AutoDisposeFutureProviderRef<List<Application>>;
String _$companyProfileHash() => r'b9ca4a0744112a65300126f2df741025c7f82ab3';

/// See also [companyProfile].
@ProviderFor(companyProfile)
final companyProfileProvider =
    AutoDisposeFutureProvider<CompanyProfile?>.internal(
  companyProfile,
  name: r'companyProfileProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$companyProfileHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef CompanyProfileRef = AutoDisposeFutureProviderRef<CompanyProfile?>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
