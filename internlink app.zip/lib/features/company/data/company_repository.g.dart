// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'company_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$companyRepositoryHash() => r'8e71eb981199fe68cf9ee8f549aa75b495e6719b';

/// See also [companyRepository].
@ProviderFor(companyRepository)
final companyRepositoryProvider =
    AutoDisposeProvider<CompanyRepository>.internal(
  companyRepository,
  name: r'companyRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$companyRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef CompanyRepositoryRef = AutoDisposeProviderRef<CompanyRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
