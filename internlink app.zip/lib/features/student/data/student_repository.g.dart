// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'student_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$studentRepositoryHash() => r'468d29d203d2e06b49c90124fccf9dee8b4f33f5';

/// See also [studentRepository].
@ProviderFor(studentRepository)
final studentRepositoryProvider =
    AutoDisposeProvider<StudentRepository>.internal(
  studentRepository,
  name: r'studentRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$studentRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef StudentRepositoryRef = AutoDisposeProviderRef<StudentRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
